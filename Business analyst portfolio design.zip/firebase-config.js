// Paste your Firebase web app config here (Firebase console → Project settings → Your apps).
// While apiKey is left as "YOUR_API_KEY" the site runs in local demo mode (data saved in this browser only).
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "",
  appId: ""
};

// Only these signed-in accounts can open the admin panel. Must match firestore.rules.
export const ADMIN_EMAILS = ["you@example.com"];
