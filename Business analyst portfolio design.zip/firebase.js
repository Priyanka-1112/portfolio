import { firebaseConfig, ADMIN_EMAILS } from './firebase-config.js';

const V = '10.12.2';
const CDN = (m) => `https://www.gstatic.com/firebasejs/${V}/firebase-${m}.js`;
export const isConfigured = !!firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith('YOUR');

let app, db, auth, fs, fa;
async function init() {
  if (app) return;
  const { initializeApp } = await import(CDN('app'));
  fs = await import(CDN('firestore'));
  fa = await import(CDN('auth'));
  app = initializeApp(firebaseConfig);
  db = fs.getFirestore(app);
  auth = fa.getAuth(app);
}

// ---- demo (no Firebase) fallbacks ----
const LS_CONTENT = 'ba-portfolio-content';
const LS_MSGS = 'ba-portfolio-messages';
const SS_ADMIN = 'ba-portfolio-demo-admin';
const demoListeners = new Set();
const demoUser = () => (sessionStorage.getItem(SS_ADMIN) ? { email: 'demo@local', displayName: 'Demo Admin', photoURL: '', uid: 'demo' } : null);
const readLS = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };

export async function loadContent() {
  if (!isConfigured) return readLS(LS_CONTENT, null);
  await init();
  const snap = await fs.getDoc(fs.doc(db, 'portfolio', 'content'));
  return snap.exists() ? snap.data() : null;
}

export async function saveContent(content) {
  if (!isConfigured) { localStorage.setItem(LS_CONTENT, JSON.stringify(content)); return; }
  await init();
  await fs.setDoc(fs.doc(db, 'portfolio', 'content'), { ...content, updatedAt: fs.serverTimestamp() });
}

export async function sendMessage(m) {
  const msg = { name: m.name.trim(), email: m.email.trim(), topic: m.topic || '', message: m.message.trim() };
  if (!isConfigured) {
    const list = readLS(LS_MSGS, []);
    list.unshift({ ...msg, id: String(Date.now()), createdAt: Date.now() });
    localStorage.setItem(LS_MSGS, JSON.stringify(list));
    return;
  }
  await init();
  await fs.addDoc(fs.collection(db, 'messages'), { ...msg, createdAt: fs.serverTimestamp() });
}

export async function listMessages() {
  if (!isConfigured) return readLS(LS_MSGS, []);
  await init();
  const q = fs.query(fs.collection(db, 'messages'), fs.orderBy('createdAt', 'desc'));
  const snap = await fs.getDocs(q);
  return snap.docs.map((d) => {
    const x = d.data();
    return { ...x, id: d.id, createdAt: x.createdAt?.toMillis ? x.createdAt.toMillis() : x.createdAt };
  });
}

export async function deleteMessage(id) {
  if (!isConfigured) {
    localStorage.setItem(LS_MSGS, JSON.stringify(readLS(LS_MSGS, []).filter((m) => m.id !== id)));
    return;
  }
  await init();
  await fs.deleteDoc(fs.doc(db, 'messages', id));
}

export async function signInWithGoogle() {
  if (!isConfigured) {
    sessionStorage.setItem(SS_ADMIN, '1');
    demoListeners.forEach((cb) => cb(demoUser()));
    return;
  }
  await init();
  const provider = new fa.GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  await fa.signInWithPopup(auth, provider);
}

export async function signOutUser() {
  if (!isConfigured) {
    sessionStorage.removeItem(SS_ADMIN);
    demoListeners.forEach((cb) => cb(null));
    return;
  }
  await init();
  await fa.signOut(auth);
}

export async function onAuth(cb) {
  if (!isConfigured) {
    demoListeners.add(cb);
    cb(demoUser());
    return () => demoListeners.delete(cb);
  }
  await init();
  return fa.onAuthStateChanged(auth, cb);
}

export function isAdmin(user) {
  if (!user) return false;
  if (!isConfigured) return true;
  return ADMIN_EMAILS.map((e) => e.toLowerCase()).includes((user.email || '').toLowerCase());
}
